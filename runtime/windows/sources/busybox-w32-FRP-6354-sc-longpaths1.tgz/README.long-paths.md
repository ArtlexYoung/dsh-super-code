# Windows 长路径修复分支

本分支从 `5f09fb446adf81d005f0aad9dc47eca19ac3b74c`（FRP-6354）开始，只修改 Windows Unicode 文件命令的路径边界。GPL 许可证保持不变。

`FEATURE_LONG_PATHS` 只允许在现有 UTF-8 配置中启用。文件系统接口转换成宽字符路径；超过普通 Windows 路径长度时，转换为对应的扩展绝对路径，UNC 使用自己的前缀。命令参数和输出不暴露内部前缀，短路径保留原有写法。无需修改 `LongPathsEnabled`。

Linux 构建使用固定的 LLVM-MinGW 20261104 MSVCRT 工具链及上游 `mingw64u_defconfig`、`mingw64a_defconfig`：

工具链文件为 `llvm-mingw-20261104-msvcrt-ubuntu-22.04-x86_64.tar.xz`，SHA-256 为 `6e3342e2e0dfa56e9178f3c34b198f278bd5e603db4a759455d1439cc2230630`，从 [LLVM-MinGW 官方发布](https://github.com/mstorsjo/llvm-mingw/releases/tag/20261104)获取。需要 Linux x86_64、make、C 编译器和 Perl；构建脚本固定 `SOURCE_DATE_EPOCH=1794300000`，可用同名环境变量明确覆盖，不依赖源码目录有 Git。

```sh
PATH="/path/to/llvm-mingw/bin:$PATH" sh examples/mswin-build/build-longpaths "/new/output"
```

产物目录必须不存在。构建脚本不会清理已有目录。完整源码、配置、工具链版本和哈希应与二进制共同保存。

在 Windows 执行实际文件回归：

```sh
node testsuite/windows-long-paths.mjs /path/to/busybox.exe
node testsuite/windows-regressions.mjs /baseline/busybox.exe /candidate/busybox.exe /path/to/testsuite
node testsuite/windows-unc-paths.mjs /path/to/busybox.exe //localhost/已准备的共享目录
```

UNC 测试使用已准备且可写的真实共享目录，并与 Node 原生重命名结果比较。Windows 共享服务可能拒绝长路径重命名，即使读取、创建和复制成功；这类限制必须在结果的 `nativeLimitations` 中保留，并确认失败时原文件未变，不能把它计为完整重命名支持。所有测试仅创建自己的随机子目录，不修改系统路径或注册表。

第二条比较受影响上游测试，新增失败必须处理；基线已有失败仍保留在输出中。GitHub 工作流分别编译和测试 x64、ARM64，在创建仓库并实际执行前，只能称为已准备的流程。

本修复不是对全部命令的长路径保证。Windows 长进程工作目录、BusyBox Shell 在该目录内 `cd` 和启动其他程序，以及 Bash、PTC、ripgrep 属于不同边界。不能以文件读取通过推导它们已经修复。

上游已有相关工作：PR #564 和维护者的 `long_paths` 分支。这里的文件接口实现独立编写；后续对上游的贡献应关联已有讨论，并以实际新增覆盖和测试结果说明差异。
